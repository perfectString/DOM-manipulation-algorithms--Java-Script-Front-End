const baseURL = "http://localhost:3030/jsonstore/matches/"

const hostInput = document.getElementById('host')
const scoreInput = document.getElementById('score')
const guestInput = document.getElementById('guest')

const addBtn = document.getElementById('add-match')
const editBtn = document.getElementById('edit-match')
const loadBtn = document.getElementById('load-matches')

const list = document.getElementById('list')

let currentEdit = null;

loadBtn.addEventListener('click', onLoad)
addBtn.addEventListener('click', onAdd)
editBtn.addEventListener('click', onEdit)

async function onLoad() {

    const response = await fetch(baseURL)
    const data = await response.json()

    list.innerHTML = ''
    editBtn.disabled = true

    const matches = Object.values(data)

    for (const match of matches) {

        const li = document.createElement('li')
        li.className = "match"

        const div = document.createElement('div')
        div.className = "info"

        const hostP = document.createElement('p')
        const scoreP = document.createElement('p')
        const guestP = document.createElement('p')

        hostP.textContent = match.host
        scoreP.textContent = match.score
        guestP.textContent = match.guest

        const divBtn = document.createElement('div')
        divBtn.className = 'btn-wrapper'

        const changeBtn = document.createElement('button')
        const delBtn = document.createElement('button')

        changeBtn.className = 'change-btn'
        delBtn.className = 'delete-btn'

        delBtn.textContent = "Delete"
        changeBtn.textContent = "Change"

        divBtn.appendChild(changeBtn)
        divBtn.appendChild(delBtn)

        div.appendChild(hostP)
        div.appendChild(scoreP)
        div.appendChild(guestP)


        li.appendChild(div)
        li.appendChild(divBtn)

        li.dataset.id = match._id

        list.appendChild(li)

        changeBtn.addEventListener('click', () => {
            hostInput.value = match.host
            scoreInput.value = match.score
            guestInput.value = match.guest;

            currentEdit = match._id;

            editBtn.disabled = false;
            addBtn.disabled = true;
        })

        delBtn.addEventListener('click', ()=>{
        onDelete(match._id, li)
        })
    }
}

async function onAdd(e) {
    e.preventDefault()

    const host = hostInput.value.trim()
    const score = scoreInput.value.trim()
    const guest = guestInput.value.trim()

    if (host === '' || score === '' || guest === '') {
        return;
    }

    await fetch(baseURL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ host, score, guest })
    })

    await onLoad()
    clearInputs()
}

async function onEdit(e) {
    e.preventDefault()
    editBtn.disabled = false
    addBtn.disabled = true

    if(!currentEdit){
        return
    }

    const host = hostInput.value.trim()
    const score = scoreInput.value.trim()
    const guest = guestInput.value.trim()

  await fetch(`${baseURL}${currentEdit}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ host, score, guest, _id: currentEdit })
    })

    await onLoad()
    clearInputs()
    editBtn.disabled = true
    addBtn.disabled = false
}

async function onDelete(id, container) {
    await fetch(`${baseURL}${id}`, {
    method: 'DELETE'
})

container.remove()
await onLoad()
}

function clearInputs() {
    hostInput.value = ''
    scoreInput.value = ''
    guestInput.value = ''
    currentEdit = null;
}